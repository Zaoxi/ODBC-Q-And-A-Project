//#include <stdio.h>
//#include <Windows.h>
//#include <sql.h>
//#include <sqlext.h>
//
//
//bool DBConnect();
//void DBDisconnect();
//
//SQLHENV hEnv = NULL;
//SQLHDBC hDbc = NULL;
//
//bool DBConnect()
//{
//	SQLRETURN Ret;
//
//	// Allocate the Environment Handle (hEnv)
//	if (SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv) != SQL_SUCCESS)
//	{
//		return false;
//	}
//
//	// Set Attributes of the Environment Handle (hEnv)
//	if (SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER) != SQL_SUCCESS)
//	{
//		return false;
//	}
//
//	// Allocate the Connection Handle(hDbc)
//	if (SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hDbc) != SQL_SUCCESS)
//	{
//		return false;
//	}
//
//	//Connect to the Server with ODBC
//	Ret = SQLConnect(hDbc, (SQLCHAR *)"DB01_Server", SQL_NTS, (SQLCHAR *)"DB01", SQL_NTS, (SQLCHAR *)"sakagami14", SQL_NTS);
//	if ((Ret != SQL_SUCCESS) && (Ret != SQL_SUCCESS_WITH_INFO))
//	{
//		return false;
//	}
//
//	return true;
//}
//
//void DBDisconnect()
//{
//	SQLDisconnect(hDbc);
//	SQLFreeHandle(SQL_HANDLE_DBC, hDbc);
//	SQLFreeHandle(SQL_HANDLE_ENV, hEnv);
//}
//
//int main(int args, char *argv[])
//{
//	if (DBConnect() == true)
//	{
//		static SQLCHAR query[100];
//		SQLHSTMT hStmt;
//
//		SQLSMALLINT colCount = -1; // column �� ����
//		SQLCHAR data[50][20]; 
//		SQLINTEGER nulldata[50];
//
//		int i;
//
//		if (SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt) == SQL_SUCCESS)
//		{
//			sprintf((char *)query, "SELECT * FROM EMPLOYEE");
//			SQLExecDirect(hStmt, query, SQL_NTS);
//			SQLNumResultCols(hStmt, &colCount);
//
//			for (i = 0; i < colCount; i++)
//			{
//				SQLBindCol(hStmt, i + 1, SQL_C_CHAR, data[i], sizeof(data[i]), &nulldata[i]);
//			}
//
//			while (SQLFetch(hStmt) != SQL_NO_DATA)
//			{
//				for (i = 0; i < colCount; i++)
//				{
//					if (nulldata[i] == SQL_NULL_DATA)
//						printf("NULL ");
//					else
//						printf("%-6s", data[i]);
//				}
//
//				printf("\n");
//			}
//
//			SQLCloseCursor(hStmt);
//			SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
//		}
//
//		DBDisconnect();
//	}
//	else
//	{
//		printf("Fail to Connection!!");
//	}
//
//
//	return 0;
//}